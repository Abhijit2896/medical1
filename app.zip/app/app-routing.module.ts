import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailsComponent } from './details/details.component';
import { ProductEntryComponent } from './product-entry/product-entry.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { ViewOrderComponent } from './view-order/view-order.component';

const routes: Routes = [
  // {
  //   path:'vieworder',
  //   component:ViewOrderComponent
  // },
  // {
  //   path:'productentry',
  //   component:ProductEntryComponent
  // },
  // {
  //   path:'viewdatails',
  //   component:ViewDetailsComponent
  // },
  {
    path:'details',
    component:DetailsComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
